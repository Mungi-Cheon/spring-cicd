package com.fc.testcicd.service;

public interface TestService {

    String getTestString();
}
